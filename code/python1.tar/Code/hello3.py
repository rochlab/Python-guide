#!/usr/bin/env  python3
#author hexu
money = float(input('enter amount\n'))
inrate = float(input('enter interest rate\n'))

period = int(input('enter period\n'))
value = 0
year = 1

while year <= period:
	value = money + (inrate*money)
	print("Year {} Rs. {:.2f}".format(year,value))
	money = value
	year = year + 1
