#!/usr/bin/env python3
#author hexu

print('Hello World!')

