#!/usr/bin/env python3
#author hexu

num = int(input('enter a number\n'))

if num <= 100:
	print('your number is smaller than 100')
else:
	print('your number is larger than 100')

